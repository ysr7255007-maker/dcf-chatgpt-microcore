
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]

def read(path):
    return (ROOT / path).read_text(encoding='utf-8')

def write(path, text):
    (ROOT / path).write_text(text, encoding='utf-8')

def replace_once(text, old, new, label):
    count = text.count(old)
    if count != 1:
        raise RuntimeError(f'{label}: expected one match, found {count}')
    return text.replace(old, new, 1)

app = read('src/ui/app.js')

helpers = r'''
function valueAtPath(source, path) {
  let current = source;
  for (const part of Array.isArray(path) ? path : []) {
    if (current == null || typeof current !== 'object') return undefined;
    current = current[part];
  }
  return current;
}

function partialMatch(value, expected) {
  if (expected && typeof expected === 'object' && !Array.isArray(expected)) {
    if (!value || typeof value !== 'object') return false;
    return Object.entries(expected).every(([key, child]) => partialMatch(value[key], child));
  }
  return Object.is(value, expected);
}

function resolveUiStateSpec(spec, sources = {}) {
  if (!spec || typeof spec !== 'object') return { stateful: false, active: false, state: '', label: null };
  const source = sources[String(spec.source || 'runtime')] || {};
  const value = valueAtPath(source, spec.path || []);
  const cases = spec.cases && typeof spec.cases === 'object' ? spec.cases : {};
  const selectedCase = Object.prototype.hasOwnProperty.call(cases, String(value)) ? cases[String(value)] : null;
  if (selectedCase && typeof selectedCase === 'object') {
    return { stateful: true, active: true, state: String(selectedCase.state || 'selected'), label: selectedCase.label || null, value };
  }
  if (Object.prototype.hasOwnProperty.call(spec, 'equals') && Object.is(value, spec.equals)) {
    return { stateful: true, active: true, state: String(spec.state || 'selected'), label: spec.label || null, value };
  }
  if (spec.matches && partialMatch(value, spec.matches)) {
    return { stateful: true, active: true, state: String(spec.state || 'selected'), label: spec.label || null, value };
  }
  return { stateful: true, active: false, state: '', label: null, value };
}

'''
app = replace_once(app, 'function createApp(options) {', helpers + 'function createApp(options) {', 'ui state helpers')

app = replace_once(
    app,
    "  const { engine, ammo, packageManager, maintenance, commandRunner, reconciler, storage, version } = options;",
    "  const { engine, ammo, packageManager, maintenance, commandRunner, reconciler, storage, version } = options;\n  const getRuntimeUiState = typeof options.getRuntimeUiState === 'function' ? options.getRuntimeUiState : () => ({});",
    'runtime ui state provider'
)

old_css = "button{border:1px solid #9995;border-radius:9px;background:transparent;color:inherit;padding:6px 8px;cursor:pointer}button:hover{background:#8882}button.danger{border-color:#dc262666}"
new_css = "button{border:1px solid #9995;border-radius:9px;background:transparent;color:inherit;padding:6px 8px;cursor:pointer}button:hover{background:#8882}button.danger{border-color:#dc262666}button.stateful{position:relative;padding-left:20px;transition:background .16s ease,border-color .16s ease,box-shadow .16s ease}button.stateful:before{content:'';position:absolute;left:8px;top:50%;width:6px;height:6px;border-radius:999px;transform:translateY(-50%);background:#9998}button.state-selected{background:#2563eb24;border-color:#2563eb99;box-shadow:inset 0 0 0 1px #2563eb22}button.state-selected:before{background:#2563eb}button.state-armed{background:#d9770626;border-color:#d97706aa;box-shadow:inset 0 0 0 1px #d9770622}button.state-armed:before{background:#d97706}button.state-running{background:#7c3aed28;border-color:#7c3aedaa;box-shadow:inset 0 0 0 1px #7c3aed22}button.state-running:before{background:#7c3aed}button.state-complete{background:#16a34a26;border-color:#16a34aaa;box-shadow:inset 0 0 0 1px #16a34a22}button.state-complete:before{background:#16a34a}button.state-send{background:#16a34a20;border-color:#16a34a88}button.state-send:before{background:#16a34a}button.state-insert{background:#2563eb20;border-color:#2563eb88}button.state-insert:before{background:#2563eb}"
app = replace_once(app, old_css, new_css, 'stateful button css')

old_ammo = '<button data-action="ammo-mode">${escapeHtml(labels.fire_mode)}：${mode === \'send\' ? \'直接发送\' : \'填入输入框\'}</button>'
new_ammo = '<button data-action="ammo-mode" class="stateful ${mode === \'send\' ? \'state-send\' : \'state-insert\'}" data-command-state="${mode === \'send\' ? \'send\' : \'insert\'}">${escapeHtml(labels.fire_mode)}：${mode === \'send\' ? \'直接发送\' : \'填入输入框\'}</button>'
app = replace_once(app, old_ammo, new_ammo, 'ammo mode state')

state_helpers = r'''
  function commandPresentation(command) {
    const baseLabel = String(command && (command.label || command.title || command.id) || '命令');
    const resolved = resolveUiStateSpec(command && command.ui_state, {
      runtime: getRuntimeUiState() || {},
      user: engine.getRoot().user || {},
      environment: engine.getEnvironment() || {}
    });
    return Object.assign({ base_label: baseLabel, label: baseLabel }, resolved, { label: resolved.label || baseLabel });
  }

  function applyCommandButtonState(button, command) {
    const presentation = commandPresentation(command);
    for (const name of ['state-selected', 'state-armed', 'state-running', 'state-complete']) button.classList.remove(name);
    if (presentation.stateful) button.classList.add('stateful');
    else button.classList.remove('stateful');
    if (presentation.state) button.classList.add(`state-${presentation.state}`);
    button.textContent = presentation.label;
    if (presentation.stateful) button.setAttribute('aria-pressed', presentation.active ? 'true' : 'false');
    else button.removeAttribute('aria-pressed');
    button.dataset.commandState = presentation.state || 'inactive';
  }

  function commandButtonHtml(module, entry) {
    const presentation = commandPresentation(entry.command);
    const classes = ['module-command-button'];
    if (presentation.stateful) classes.push('stateful');
    if (presentation.state) classes.push(`state-${presentation.state}`);
    const pressed = presentation.stateful ? ` aria-pressed="${presentation.active ? 'true' : 'false'}"` : '';
    return `<button class="${classes.join(' ')}" data-action="module-command" data-module-id="${escapeHtml(module.id)}" data-command-id="${escapeHtml(entry.command.id)}" data-command-state="${escapeHtml(presentation.state || 'inactive')}"${pressed}>${escapeHtml(presentation.label)}</button>`;
  }

  function refreshCommandStates() {
    for (const button of root.querySelectorAll('button[data-action="module-command"]')) {
      const module = engine.getRegistry().modules.find((entry) => String(entry.id) === String(button.dataset.moduleId));
      const found = module && commandList(module).find((entry) => String(entry.command.id) === String(button.dataset.commandId));
      if (found) applyCommandButtonState(button, found.command);
    }
  }

'''
app = replace_once(
    app,
    '  function renderModuleCards(modules, role, emptyText) {',
    state_helpers + '  function renderModuleCards(modules, role, emptyText) {',
    'command state rendering'
)

old_button = '<button data-action="module-command" data-module-id="${escapeHtml(module.id)}" data-command-id="${escapeHtml(entry.command.id)}">${escapeHtml(entry.command.label || entry.command.title || entry.command.id)}</button>'
app = replace_once(app, old_button, '${commandButtonHtml(module, entry)}', 'module command button rendering')

old_roles = '<button data-action="module-role" data-module-id="${escapeHtml(module.id)}" data-module-role="daily">日常功能</button><button data-action="module-role" data-module-id="${escapeHtml(module.id)}" data-module-role="maintenance">维护工具</button>'
new_roles = '<button data-action="module-role" data-module-id="${escapeHtml(module.id)}" data-module-role="daily" class="stateful ${classification.role === \'daily\' ? \'state-selected\' : \'\'}" aria-pressed="${classification.role === \'daily\' ? \'true\' : \'false\'}">日常功能</button><button data-action="module-role" data-module-id="${escapeHtml(module.id)}" data-module-role="maintenance" class="stateful ${classification.role === \'maintenance\' ? \'state-selected\' : \'\'}" aria-pressed="${classification.role === \'maintenance\' ? \'true\' : \'false\'}">维护工具</button>'
app = replace_once(app, old_roles, new_roles, 'role state buttons')

old_profile = '<button data-action="profile-activate" data-profile-id="${escapeHtml(profile.id)}">激活</button>'
new_profile = '<button data-action="profile-activate" data-profile-id="${escapeHtml(profile.id)}" class="stateful ${profileState.active_id === profile.id ? \'state-selected\' : \'\'}" aria-pressed="${profileState.active_id === profile.id ? \'true\' : \'false\'}">${profileState.active_id === profile.id ? \'当前环境\' : \'激活\'}</button>'
app = replace_once(app, old_profile, new_profile, 'profile state button')

app = replace_once(
    app,
    "  return { render, setNotice, captureRuntimeViews, destroy: () => hostElement.remove(), root, shell, hostElement };",
    "  return { render, refreshCommandStates, setNotice, captureRuntimeViews, destroy: () => hostElement.remove(), root, shell, hostElement };",
    'app state refresh export'
)
app = replace_once(
    app,
    'module.exports = { createApp, computeFenceStyle };',
    'module.exports = { createApp, computeFenceStyle, resolveUiStateSpec };',
    'ui resolver export'
)
write('src/ui/app.js', app)

index = read('src/index.js')
index = replace_once(
    index,
    "  app = createApp({ engine, ammo, packageManager, maintenance, commandRunner, reconciler, storage, version: VERSION });",
    '''  app = createApp({
    engine, ammo, packageManager, maintenance, commandRunner, reconciler, storage, version: VERSION,
    getRuntimeUiState: () => ({
      conversation_performance: conversationPerformance.diagnostics(),
      conversation_turn_attribution: conversationTurnAttribution.status()
    })
  });''',
    'runtime ui state wiring'
)
index = replace_once(
    index,
    "  host.startSendObserver((signal) => conversationTurnAttribution.onSend(signal));",
    '''  host.startSendObserver((signal) => {
    const state = conversationTurnAttribution.onSend(signal);
    if (state.accepted && app) app.refreshCommandStates();
  });''',
    'send state refresh'
)
index = replace_once(
    index,
    "    onReplyStart: (meta) => conversationTurnAttribution.onReplyStart(meta)",
    '''    onReplyStart: (meta) => {
      const state = conversationTurnAttribution.onReplyStart(meta);
      if (state.accepted && app) app.refreshCommandStates();
    }''',
    'reply start state refresh'
)
write('src/index.js', index)

print(json.dumps({'ok': True, 'step': 2}, ensure_ascii=False))
