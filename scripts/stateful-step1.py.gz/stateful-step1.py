
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]

def read(path):
    return (ROOT / path).read_text(encoding='utf-8')

def write(path, text):
    target = ROOT / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(text, encoding='utf-8')

def replace_once(text, old, new, label):
    count = text.count(old)
    if count != 1:
        raise RuntimeError(f'{label}: expected one match, found {count}')
    return text.replace(old, new, 1)

constants = read('src/core/constants.js')
constants = replace_once(constants, "const VERSION = '0.18.1';", "const VERSION = '0.18.2';", 'version')
write('src/core/constants.js', constants)

package = json.loads(read('package.json'))
package['version'] = '0.18.2'
needle = 'node tests/dcf-conversation-turn-attribution.unit.test.js && '
if needle not in package['scripts']['test']:
    raise RuntimeError('test insertion point missing')
package['scripts']['test'] = package['scripts']['test'].replace(
    needle,
    needle + 'node tests/dcf-stateful-command-feedback.unit.test.js && ',
    1
)
write('package.json', json.dumps(package, ensure_ascii=False, indent=2) + '\n')

packs = read('src/modules/standard-packages.js')
packs = replace_once(
    packs,
    "revision: '1.2.0',\n    title: '长对话减负'",
    "revision: '1.3.0',\n    title: '长对话减负'",
    'performance package revision'
)
packs = replace_once(
    packs,
    "id: 'dcf.standard.conversation-performance', title: '长对话减负', version: '1.2.0'",
    "id: 'dcf.standard.conversation-performance', title: '长对话减负', version: '1.3.0'",
    'performance module revision'
)

old_modes = """          { id: 'safe', label: '透明减负（推荐）', steps: [{ call: 'conversation.performance.configure', with: { mode: 'safe' } }] },
          { id: 'window40', label: '窗口化：最近 40 条', steps: [{ call: 'conversation.performance.configure', with: { mode: 'window', keep_recent: 40 } }] },
          { id: 'window20', label: '窗口化：最近 20 条', steps: [{ call: 'conversation.performance.configure', with: { mode: 'window', keep_recent: 20 } }] },
          { id: 'off', label: '恢复全部并关闭', steps: [{ call: 'conversation.performance.configure', with: { mode: 'off' } }] }
"""
new_modes = """          { id: 'safe', label: '透明减负（推荐）', ui_state: { source: 'runtime', path: ['conversation_performance'], matches: { mode: 'safe' }, state: 'selected', label: '透明减负 · 已开启' }, steps: [{ call: 'conversation.performance.configure', with: { mode: 'safe' } }] },
          { id: 'window40', label: '窗口化：最近 40 条', ui_state: { source: 'runtime', path: ['conversation_performance'], matches: { mode: 'window', keep_recent: 40 }, state: 'selected', label: '最近 40 条 · 已开启' }, steps: [{ call: 'conversation.performance.configure', with: { mode: 'window', keep_recent: 40 } }] },
          { id: 'window20', label: '窗口化：最近 20 条', ui_state: { source: 'runtime', path: ['conversation_performance'], matches: { mode: 'window', keep_recent: 20 }, state: 'selected', label: '最近 20 条 · 已开启' }, steps: [{ call: 'conversation.performance.configure', with: { mode: 'window', keep_recent: 20 } }] },
          { id: 'off', label: '恢复全部并关闭', ui_state: { source: 'runtime', path: ['conversation_performance'], matches: { mode: 'off' }, state: 'selected', label: '长对话减负 · 已关闭' }, steps: [{ call: 'conversation.performance.configure', with: { mode: 'off' } }] }
"""
packs = replace_once(packs, old_modes, new_modes, 'performance mode states')

old_turn = """          { id: 'turn_attribution_arm', label: '记录下一轮问答', steps: [{ call: 'conversation.performance.turn.arm' }] },
          { id: 'turn_attribution_copy', label: '复制本轮归因报告', steps: [{ call: 'conversation.performance.turn.report', with: { finish: false } }] },
          { id: 'turn_attribution_finish', label: '手动结束并复制', steps: [{ call: 'conversation.performance.turn.report', with: { finish: true } }] }
"""
new_turn = """          { id: 'turn_attribution_arm', label: '记录下一轮问答', ui_state: { source: 'runtime', path: ['conversation_turn_attribution', 'status'], cases: { armed: { state: 'armed', label: '记录下一轮问答 · 等待发送' }, running: { state: 'running', label: '本轮问答 · 记录中' } } }, steps: [{ call: 'conversation.performance.turn.arm' }] },
          { id: 'turn_attribution_copy', label: '复制本轮归因报告', ui_state: { source: 'runtime', path: ['conversation_turn_attribution', 'status'], cases: { complete: { state: 'complete', label: '复制本轮归因报告 · 可复制' } } }, steps: [{ call: 'conversation.performance.turn.report', with: { finish: false } }] },
          { id: 'turn_attribution_finish', label: '手动结束并复制', steps: [{ call: 'conversation.performance.turn.report', with: { finish: true } }] }
"""
packs = replace_once(packs, old_turn, new_turn, 'turn attribution states')
write('src/modules/standard-packages.js', packs)

turn_test = read('tests/dcf-conversation-turn-attribution.unit.test.js')
turn_test = replace_once(
    turn_test,
    "assert.strictEqual(pack.revision, '1.2.0');",
    "assert.strictEqual(pack.revision, '1.3.0');",
    'turn package revision test'
)
turn_test = replace_once(
    turn_test,
    "assert(commands.some((command) => command.id === 'turn_attribution_arm' && command.label === '记录下一轮问答'));",
    "assert(commands.some((command) => command.id === 'turn_attribution_arm' && command.label === '记录下一轮问答' && command.ui_state));",
    'turn arm ui state test'
)
write('tests/dcf-conversation-turn-attribution.unit.test.js', turn_test)

state_test = r"""'use strict';

const assert = require('assert');
const fs = require('fs');
const path = require('path');
const { resolveUiStateSpec } = require('../src/ui/app');
const { STANDARD_PACKS } = require('../src/modules/standard-packages');

let state = resolveUiStateSpec(
  { source: 'runtime', path: ['performance'], matches: { mode: 'window', keep_recent: 40 }, state: 'selected', label: '最近 40 条 · 已开启' },
  { runtime: { performance: { mode: 'window', keep_recent: 40 } } }
);
assert.strictEqual(state.active, true);
assert.strictEqual(state.state, 'selected');
assert.strictEqual(state.label, '最近 40 条 · 已开启');

state = resolveUiStateSpec(
  { source: 'runtime', path: ['turn', 'status'], cases: { armed: { state: 'armed', label: '等待发送' }, running: { state: 'running', label: '记录中' } } },
  { runtime: { turn: { status: 'armed' } } }
);
assert.strictEqual(state.state, 'armed');
assert.strictEqual(state.label, '等待发送');

state = resolveUiStateSpec(
  { source: 'runtime', path: ['turn', 'status'], cases: { complete: { state: 'complete', label: '可复制' } } },
  { runtime: { turn: { status: 'running' } } }
);
assert.strictEqual(state.active, false);
assert.strictEqual(state.state, '');

const pack = STANDARD_PACKS.find((item) => item.pack_id === 'dcf.standard.conversation-performance');
assert.strictEqual(pack.revision, '1.3.0');
const commands = pack.modules[0].blocks.flatMap((block) => block.commands);
for (const id of ['safe', 'window40', 'window20', 'off', 'turn_attribution_arm', 'turn_attribution_copy']) {
  const command = commands.find((item) => item.id === id);
  assert(command && command.ui_state, `missing declarative ui_state for ${id}`);
}

const appSource = fs.readFileSync(path.join(__dirname, '..', 'src', 'ui', 'app.js'), 'utf8');
for (const marker of ['state-selected', 'state-armed', 'state-running', 'state-complete', 'aria-pressed', 'refreshCommandStates']) {
  assert(appSource.includes(marker), `missing UI state marker ${marker}`);
}
const indexSource = fs.readFileSync(path.join(__dirname, '..', 'src', 'index.js'), 'utf8');
assert(indexSource.includes('getRuntimeUiState'));
assert(indexSource.includes('app.refreshCommandStates()'));

console.log(JSON.stringify({
  ok: true,
  declarative_state_contract: true,
  selected_mode_feedback: true,
  armed_running_complete_feedback: true,
  text_and_color_feedback: true,
  live_turn_refresh: true,
  unrelated_actions_unstyled: true
}, null, 2));
"""
write('tests/dcf-stateful-command-feedback.unit.test.js', state_test)

print(json.dumps({'ok': True, 'step': 1}, ensure_ascii=False))
