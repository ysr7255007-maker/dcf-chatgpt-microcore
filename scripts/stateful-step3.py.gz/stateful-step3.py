
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def read(path):
    return (ROOT / path).read_text(encoding='utf-8')

def write(path, text):
    target = ROOT / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(text, encoding='utf-8')

readme = read('README.md')
readme = readme.replace('DCF `0.18.1` keeps a generic modular kernel', 'DCF `0.18.2` keeps a generic modular kernel', 1)
readme += '''

## Stateful command feedback

DCF `0.18.2` adds a finite declarative `ui_state` contract for commands whose current state can be observed reliably. Selected modes, armed diagnostics, running diagnostics and completed reports receive distinct color, a status dot, updated wording and `aria-pressed`; one-shot actions remain visually neutral. The question-answer attribution controls refresh in place when send/reply lifecycle events change, avoiding a full panel rerender. Current module roles, the active environment Profile and the ammo firing mode use the same visible-state convention.
'''
write('README.md', readme)

current = read('docs/current-state.md')
current = current.replace('当前正式版本：`0.18.1`', '当前正式版本：`0.18.2`', 1)
current = current.replace('`0.18.1` 修复 userscript 升级后能力包仍受旧 Catalog 节流影响的问题。', '`0.18.1` 修复 userscript 升级后能力包仍受旧 Catalog 节流影响的问题。`0.18.2` 为可判定状态的命令增加颜色、状态点、文字和无障碍反馈。', 1)
current += '''

## 0.18.2 有状态控件反馈

- `dcf.standard.conversation-performance@1.3.0` 为减负模式和问答轮次归因声明有限 `ui_state`。
- “记录下一轮问答”在待命时显示琥珀色“等待发送”，发送后显示蓝紫色“记录中”；自动完成后“复制本轮归因报告”显示绿色“可复制”。
- 当前减负模式、弹药发射模式、功能分区和激活 Profile 都提供持续可见的选中反馈。
- 颜色之外同时提供文字变化、状态点和 `aria-pressed`，不能只靠颜色传达状态。
- 只有能够从权威用户状态或有限 Runtime 观察可靠计算的命令可以声明状态；普通一次性动作保持中性。
'''
write('docs/current-state.md', current)

maintenance = read('docs/dcf-maintenance-skill.md')
maintenance += '''

## 十五、有状态控件反馈

开关、模式、待命、运行、完成和当前选择等控件必须提供持续状态反馈，不能只在点击瞬间显示通知。状态反馈至少包含颜色或状态点之外的文字/无障碍语义。模块命令通过有限声明式 `ui_state` 读取权威用户状态、Environment Snapshot 或白名单 Runtime 状态；不得按按钮标题猜测状态，也不得让一次性动作在执行后长期保持“开启”颜色。Runtime 状态变化应优先局部刷新按钮，不为颜色变化重绘整个工作区。
'''
write('docs/dcf-maintenance-skill.md', maintenance)

status = read('docs/adr/status-index.md')
status = status.replace('## Current\n', '## Current\n\n- `2026-07-14-dcf-stateful-command-feedback.md` — **accepted**\n', 1)
write('docs/adr/status-index.md', status)

adr = '''# ADR: Stateful command feedback

Date: 2026-07-14  
Status: accepted

## Context

Several DCF controls represent durable or live state, but were rendered like one-shot actions. After arming the next question-answer attribution, the button looked unchanged, so the user could not tell whether the click had taken effect. The same ambiguity applied to mutually exclusive performance modes and other current selections.

## Decision

- Add a finite declarative `command.ui_state` contract resolved only against named user/environment/runtime state sources.
- Render stateful controls with a status dot, distinct border/background, state-aware wording and `aria-pressed`.
- Use separate visual states for selected, armed, running and complete.
- Refresh question-answer command states in place on send and first-reply lifecycle signals; completion may continue to render the normal completion notice.
- Apply the same selected-state convention to current module role, active Profile and ammo firing mode.
- Leave one-shot actions visually neutral unless a reliable continuing state is declared.

## Boundaries

- State is never inferred from Chinese labels or the most recent command receipt.
- Color is not the sole signal.
- Package authors cannot query arbitrary page DOM through `ui_state`; runtime sources are supplied by the trusted bootstrap as a finite snapshot.
- A command that merely succeeded is not automatically considered active.
'''
write('docs/adr/2026-07-14-dcf-stateful-command-feedback.md', adr)

print('ok')
